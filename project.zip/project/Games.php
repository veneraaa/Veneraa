<html>
<head>
  <link rel="stylesheet" type="text/css" href="Game.css">
  <title>my_page</title>
</head> 
<body>

<div >
<p><a href="logout.php"><button id = "logout">Log Out </button></a></p>
<?php include('header.php') ?>
<?php include('footer.php') ?>
<section>
	
  	<object width="500" height="400">
	    <param name="movie" value="games/bigfish.swf">
	    <embed src="games/bigfish.swf" width="100" height="70"></embed>
	</object>
</section>

<footer>
venera.kali © SDUdent
</footer>
</div>
</body>
</html>