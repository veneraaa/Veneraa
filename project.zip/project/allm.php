<html>
<head>
	<link rel="stylesheet" type="text/css" href="my_friends.css">
	<title>my_messages</title>
</head>	
<body>


<div>
<?php include('header.php') ?>
<?php include('footer.php') ?>

<div>
	<h3>My messages</h3>
	<?php
	//$uid = $_GET['id'];
	require("connection.php");
	$myId=$_SESSION['myid'];

	$query = "SELECT * FROM friends WHERE myid= '$myId' ";
	$result = mysql_query($query);
	while($row = mysql_fetch_array($result)){

		$fid=$row['fid'];

		$q = "SELECT * FROM regis WHERE id=$fid";
		$res = mysql_query($q);
		while($r = mysql_fetch_array($res)){
			echo "<div class='item'>
			<p><img src='".$r['src']."'></p><p>".$r['name']. " " .$r['surname']."</p>
			<a href='messages.php?id=".$r['id']."' id = 'mass'>show messages</a></div>";
		
	}
}
	?>
	
	<p><a href="logout.php"><button id = "logout">Log Out </button></a></p>
	

</div>
</div>

<footer>
venera.kali © SDUdent.kz
</footer>
</div>
</body>
</html>