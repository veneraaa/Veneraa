<?php
	$con = mysql_connect('localhost', 'root', '');
	if (!$con){
	die("couldn't connect".mysql_error());
	}
	mysql_select_db("a04");
	?>