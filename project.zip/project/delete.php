<?php
	include ("connection.php");
	session_start();
	if(isset($_SESSION["myid"])) {
		$id = (int)$_SESSION["myid"];
		$sql = "DELETE FROM `regis` WHERE id=\"$id\"";
	}
	mysql_query($sql);
	session_destroy();
	header("Location:index.php");
?>