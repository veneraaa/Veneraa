
<html>
<head>
	<link rel="stylesheet" type="text/css" href="my_friends.css">
	<title>my_friends</title>
	<style type="text/css">
		.box {
			position: relative;
			top: 40px;
			left: 50px;
		}
		.text {
			padding: 9px 8px 9px;
			font-size: 14px;
		}
	</style>
</head>	
<body>


<div>
<?php include('header.php') ?>
<?php include('footer.php') ?>
<?php include('connection.php'); if(isset($_POST["save"])) {
			$id = (int)$_SESSION["myid"];
			$city = $_POST["city"];
			$name = $_POST["name"];
			$surname = $_POST["surname"];
			$password = $_POST["password"];
			$sql = "UPDATE `regis` SET `city`=\"$city\",`name`=\"$name\", `surname`=\"$surname\",`password`=\"$password\" WHERE id=\"$id\"";
			mysql_query($sql);
		}
		else if(isset($_POST["delete"])) {
			if(isset($_SESSION["myid"])) {
				$id = (int)$_SESSION["myid"];
				$sql = "DELETE FROM `regis` WHERE id=\"$id\"";
			}
			mysql_query($sql);
			session_destroy();
			header("Location:index.php");

		} ?> 

	<div>
		<form method="POST">
			<div class="box" style="top:50px;">
				<input type="text" class="text" name="name" placeholder="Name" >
			</div>
			<div class="box" style="top:75px;">
				<input type="text" class="text" name="surname" placeholder="Surname" >
			</div>
			<div class="box" style="top:100px;">
				<input type="text" class="text" name="city" placeholder="Your city">
			</div>
			<div class="box" style="top:125px;">
				<input type="password" class="text" name="password" placeholder="Password" >
			</div>
			<div class="box" style="top:150px;">
				<input type="password" class="text" name="passwordconf" placeholder="Confirm password" >
			</div>
			<div class="box" style="top:150px;">
				<input type="submit" name="delete" class="box" value="DELETE"></input>
			</div>
			<div class="box" style="top:175px;">
				<input type="submit" name="save" class="box" value="Save changes"></input>
			</div>
		</form>
	
	<p><a href="logout.php"><button id = "logout">Log Out </button></a></p>
	

	</div>
</div>

<footer>
venera.kali © SDUdent.kz
</footer>
</div>
</body>
</html>

