<link rel="stylesheet" type="text/css" href="footer.css">

<h2>
<a href='my_page.php'>My page</a></br>
<a href='my_friends.php'>My friends</a></br>
<a href="messages.php">All messages</a></br>
<a href="my_photos.php">My Photos</a></br>
<a href="edit.php">Settings</a></br>
<a href="Games.php">Games</a>
</h2>

