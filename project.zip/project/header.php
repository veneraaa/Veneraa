<header>
    SDUdent
<p id="pic"><img src="pic.gif" style="height: 100px; line-height: 100px;"></p>
<form method = "POST" action = "search.php">
<p><label for = "search"></label>
	<input type = "search" placeholder = "search people" name = "search" id = "search"></p>
<p><input type = "submit" value = "search" id = "button"></p>


</form>
<?php 
	session_start();
	if(!isset($_SESSION['myid'])){
		header("Location:login.php");
	}
 ?>
</header>


