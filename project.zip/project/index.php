<html>
<head>
	<link rel="stylesheet" type="text/css" href="index.css">
	<title>REGISTRATION</title>
</head>	
<body>
// 	<script type="text/javascript" src="jquery.js"></script>
// <script type="text/javascript">
 $(document).ready(function(){
   $("#button").click(function(){
    $("#c").show(10);
   });
</script>

<header>
    SDUdent
<p id="pic"><img src="pic.gif" style="height: 100px; line-height: 100px;"></p>
</header>

	<body>
	
			
	

<nav>
Registration
</nav>
<section>
<form method="post" enctype="multipart/form-data" action="upload.php">
			<p><label for = "login"></label><input type = "text" placeholder = "login" name = "login" id = "login"></p>
			<p><label for = "password"></label><input type = "password" placeholder = "password" name = "password1" id ="pass"></p>
			<p><input type = "password" placeholder = "Re-Password" name = "password2" id ="pass"></p>
		    <p><label for = "mail"></label><input type = "email" placeholder = "e-mail" name = "mail" id = "mail"></p>
			<p><label for = "name"></label><input type = "text" placeholder = "first name" name = "name" id = "name"></p>
			<p><label for = "surname"></label><input type = "text" placeholder = "last name" name = "surname" id = "surname"></p>
			<p><label for = "city"></label><input type = "city" placeholder = "city" name = "city" id = "city"></p>
			<p><label for = "gender"></label>male<input type="radio" name="gender" value="male" checked class="gender"> female<input type="radio" name="gender" value="female" class="gender"></p>
			<p><label for ="bday"></label> <input type="date" name="bday" max="2016-12-31" min="1900-01-01"></p>
			<p><label for="img"> </label>
				<input type="file" name="img"/>
			</p>
			<p><input  name="submit" type = "submit" value = "sign up" id = "button" ></p>
</form>	
</section>
<footer> 
venera.kali © SDUdent.kz
</footer>
</body>
</html>
