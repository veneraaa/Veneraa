
<?php 
session_start();
	 if (isset($_POST["sign"])){
		 	$login = $_POST['login'];
		 	$password = $_POST["password"];
		 	if (strlen($login)==0 || strlen($password)==0){
				echo "Fill all inputs";
			}



		    else{
	 		$sql = "SELECT * FROM regis WHERE login ='$login'  AND password = '$password'";
	  		$result = $conn->query($sql);
	  		//echo "$login";
	    	$result = $conn->query($sql);
				if(isset($result->num_rows)){
					if ($result->num_rows > 0) {
						echo "login";
						$_SESSION["login"]== TRUE;
						$result = mysql_query($query);
						while($row = mysql_fetch_array($result)){
								$_SESSION['myid'] = $row['id'];
						}
					}
					else{
						echo "wrong";
					}
				}
			}
	} else{}
	
 ?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="login.css">
	<title>MAIN</title>
</head>
	
<body>

<header>
    SDUdent
<p id="pic"><img src="pic.gif" style="height: 100px; line-height: 100px;"></p>
</header>

<nav>
Welcome!
</nav>

<section>
	<form method = "POST" action = "validation.php">

			<p><label for = "login"></label><input type = "text" placeholder = "Name" name = "login" id = "login"></p>
			
			<p><label for = "password"></label><input type = "password" placeholder = "Password" name = "password" id ="pass"></p>
			<p><a href="index.php?link=login"></a><input type="submit"  name="sign" value="Log in" id = "button"></p>

			
	</form>
	
	<a href="index.php" id = "reg">registration</a>
	<a onclick="forgot()" span style="cursor:pointer" id = "forgot">forgot your password?</span><br></a>
</section>
<script>

function forgot() {
    alert("It's not my problem! ;)");
}
</script>

<footer>
venera.kali © SDUdent
</footer>
</body>
</html>

