

<html>
<head>
	<link rel="stylesheet" type="text/css" href="my_friends.css">
	<title>make_friend</title>
</head>	
<body>
<div>
<?php include('header.php') ?>
<?php include('footer.php') ?>


<?php
    
	require 'connection.php';
	$fid = $_SESSION['fid'];
	$myid = $_SESSION['myid'];

	$sql = "INSERT INTO friends VALUES (null, '$myid', '$fid')";
	
	if(!mysql_query("$sql")){
		echo mysql_error();
	}
?>

<div>
	
	<h3>This person successfully added to your list! :) </h3>
	
	
	<p><a href="logout.php"><button id = "logout">Log Out </button></a></p>
	

</div>
</div>


<footer>
venera.kali © SDUdent.kz
</footer>
</div>
</body>
</html>