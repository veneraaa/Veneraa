
<html>
<head>
	<link rel="stylesheet" type="text/css" href="my_friends.css">
	<title>all_messages</title>
</head>	
<body>

<div>
<?php include('header.php') ?>
<?php include('footer.php') ?>

<div>
	<h3>My messages</h3>
	<?php
	$myid=$_SESSION['myid'];

	require("connection.php");
	// $fid = $_SESSION['fid'];
	// $myid = $_SESSION['myid'];

	$query = "SELECT * FROM messages WHERE myid=$myid ";
	$result = mysql_query($query);
	while($row = mysql_fetch_array($result)){
		$to=$row['fid'];
		echo "<p>".$row['message']. "</p>";
		
		$q = "SELECT * FROM regis WHERE id=$to";
		$res = mysql_query($q);
		while($r = mysql_fetch_array($res)){
			echo "<p>to: ".$r['name']. " " .$r['surname']."<br></br></p>";
		}
	}


	?>
	
	<p><a href="logout.php"><button id = "logout">Log Out </button></a></p>
	

</div>
</div>
<footer>
venera.kali © SDUdent.kz
</footer>
</div>
</body>
</html>