
<html>
<head>
	<link rel="stylesheet" type="text/css" href="my_page.css">
	<title>my_page</title>
</head>	
<body>

<div>
<?php include('header.php') ?>
<?php include('footer.php') ?>


<div>
	<?php
	//session_start();
	//$uid = $_GET['id'];
	$uid= $_SESSION["myid"];
	require("connection.php");
	$query = "SELECT * FROM regis WHERE id=$uid";
	$result = mysql_query($query);
	while($row = mysql_fetch_array($result)){
		echo "<div class='item'>
		<p><img src=".$row['src']."></p>
		<p >Name: ".$row['name']."</p>
		<p>Surname: ".$row['surname']."</p> 
		<p>Birth date:".$row['bday']."</p>
		<p>Gender: ".$row['gender']."</p>
		<p>City: ".$row['city']."</p>
		</form></div>
		</div>";}
	?>
	<p><a href="logout.php"><button id = "logout">Log Out </button></a></p>
	

</div>

<footer>
venera.kali© SDUdent
</footer>
</div>
</body>
</html>