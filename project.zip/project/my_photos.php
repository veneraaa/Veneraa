<html>
<head>
  <link rel="stylesheet" type="text/css" href="style.css" />
  <title>my_Photos</title>
</head> 
<body>
<div >
<p><a href="logout.php"><button id = "logout">Log Out </button></a></p>
<?php include('header.php') ?>
<?php include('footer.php') ?>
<section>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="action.js"></script>


<div id="pageContainer">
  <div id="slideshow">
    <div id="slidesContainer">
      <div class="slide">
        <img src="photos/grass-blades.jpg" />
      </div>
      <div class="slide">
        <img src="photos/ladybug.jpg" />
      </div>
      <div class="slide">
        <img src="photos/lightning.jpg" />
      </div>
      <div class="slide">
        <img src="photos/lotus.jpg" />
      </div>
      <div class="slide">
        <img src="photos/mojave.jpg" />
      </div>
      <div class="slide">
        <img src="photos/pier.jpg" />
      </div>
      <div class="slide">
        <img src="photos/sea-mist.jpg" />
      </div>
      <div class="slide">
        <img src="photos/stones.jpg" />
      </div>
    </div>
  </div>

</section>

<footer>
venera.kali © SDUdent
</footer>
</div>

</html>