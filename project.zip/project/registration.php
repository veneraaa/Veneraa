<?php
	session_start();
	include 'connection.php'
	if (isset($_POST["submit"])) {
	require("connection.php");
	$login = $_POST['login'];
	$password = md5($_POST['password']);
	$mail = $_POST['mail']; 
	$name = $_POST['name']; 
	$surname = $_POST['surname']; 
	$city = $_POST['city']; 
	$gender = $_POST['gender'];
	$bday = $_POST['bday']; 
	if($_FILES['img']['error']>0){
		header("Location: index.php");
	}
	$src = $_FILES['img']['name'];
	move_uploaded_file($_FILES['img']['tmp_name'], $_FILES['img']['name']);
	$sql = "INSERT INTO regis(login, password, name, surname,mail,gender,bday,city,src) VALUES('" . $login . "', '" . $password."','" . $name . "', '" . $surname."','" . $mail . "', '" . $gender."','" . $bdat. "', '" . $city."','" . $src . "') ";
	
	if(!mysql_query($sql)){
			echo mysql_error();
		}else{$_SESSION['mail']=$mail;}
		header("Location:login.php");
    }
?>

