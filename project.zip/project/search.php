

<html>
<head>
	<link rel="stylesheet" type="text/css" href="my_friends.css">
	<title>serch_result</title>
</head>	
<body>
	
<div>
<?php include('header.php') ?>
<?php include('footer.php') ?>


<div>
	<h3>search result</h3>
<?php
	require("connection.php");
	$search = $_POST['search'];
	$query = "SELECT * FROM regis WHERE name LIKE '%$search%' OR surname LIKE '%$search%'";
	$result = mysql_query($query);
	while($row = mysql_fetch_array($result)){
		echo "<div class='item'><p><img src='".$row['src']."'></p>
		<a href='user_page.php?id=".$row['id']."' id = 'mass'>".$row['name']. " " .$row['surname']."</a></div>";
	}

?>
	
	<p><a href="logout.php"><button id = "logout">Log Out </button></a></p>
	</div>
	</div>
	



	


<footer>
venera.kali © SDUdent.kz
</footer>
</div>
</body>
</html>