<?php 
	session_start();
    
	require 'connection.php';

	$mess=$_POST['message'];
	$fid = $_SESSION['fid'];
	$myid = $_SESSION['myid'];

	$sql = "INSERT INTO messages VALUES ('$mess',null, '$fid','$myid')";
	
	if(!mysql_query("$sql")){
		echo mysql_error();
	}
?>