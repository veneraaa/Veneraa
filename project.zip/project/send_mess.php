
<html>
<head>
	<link rel="stylesheet" type="text/css" href="send_mess.css">
	<title>send_message</title>
</head>	
<body>
	<header>
    SDUdent
<p id="pic"><img src="pic.gif" style="height: 100px; line-height: 100px;"></p>
</header>
	<div>

<?php include('footer.php') ?>




<?php $id = $_GET['id']; ?>


<section>
	<form method="post" action="send.php">
	        <h5>Your message</h5>
			<p><label for = "post"></label><textarea name = "message" id="message"></textarea></p>
			<p><input type = "submit" value = "Send" id = "submit"></p>
			<p><input type="hidden" value="<?php echo $id; ?>" name="id"></p>
</form>

	<p><a href="logout.php"><button id = "logout">Log Out </button></a></p>
</section>	



</div>
</div>


<footer>
venera.kali © SDUdent.kz
</footer>
</div>
</body>
</html>