

<html>
<head>
	<link rel="stylesheet" type="text/css" href="my_friends.css">
	<title>make_friend</title>
</head>	
<body>

<div>
<?php include('header.php') ?>
<?php include('footer.php') ?>
<?php
	require("connection.php");
	$message = $_POST['message'];
	$from = $_SESSION['myid'];
	$to = $_POST['id'];
	//$uid = $_SESSION['uid'];
	$sql = "INSERT INTO messages VALUES ('$from','$to','$message',null)";
	if(!mysql_query($sql)){
			echo mysql_error();
		}

?>


<div>
	
	<h3>The message was sent to your friend! :) </h3>
	
	
	<p><a href="logout.php"><button id = "logout">Log Out </button></a></p>
	

</div>

<footer>
venera.kali © SDUdent
</footer>
</div>
</body>
</html>