<?php 
	session_start();
	//print_r($_POST);
	$conn = mysqli_connect("localhost","root","","a04");
	 echo "Hello ";

		// Check connection
    if (mysqli_connect_error()){
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}
	if (isset($_POST["submit"])) {
			
			$login = $_POST["login"];
			$password1= $_POST["password1"];
			$password2 = $_POST["password2"];
			//require("connection.php");
	       
	        $mail = $_POST['mail']; 
	        $name = $_POST['name']; 
	        $surname = $_POST['surname']; 
	        $city = $_POST['city']; 
	        $gender = $_POST['gender'];
	        $bday = $_POST['bday']; 
	        if(!mysql_query($sql)){
			echo mysql_error();
		   }else{$_SESSION['mail']=$mail;}


			if ($password1 != $password2) {
				echo "not right";
			}

			else if (strlen($login)<3) {
				echo "Your login must contain more chars";
			}
			
			else{
				$conn = new mysqli("localhost","root","","a04")
				or die ("FAil".$conn->connect_error);

				  if($_FILES['img']['error']>0){
		               header("Location: index.php");
	                   }
	              if(is_uploaded_file($_FILES['img']['name'])){
	                   $src = $_FILES['img']['name'];
	                   $path="user_image/";
	                   $fullpath=$path.$src;
	                   move_uploaded_file($_FILES['img']['tmp_name'], $fullpath);
	                 echo "<br>$fullpath";
	          }
				  $sql = "INSERT INTO regis(login,password,mail,name,surname,city,gender,bday,src)
				  VALUES ('" . $login . "', '" . $password1."','" . $mail . "', '" . $name."','" . $surname . "', '" . $city."','" . $gender. "', '" . $bday."','" . $fullpath . "')";
                if(!mysql_query($sql)){
			    echo mysql_error();
		            }else{$_SESSION['mail']=$mail;}
				if ($conn->query($sql) === TRUE) {
			    	echo "New users obtained successfully";
			    	header("location: login.php");
				} 

				else{
			    	echo ("Error: " . $sql . "<br>" . mysqli_error());
				}

				$conn->close();	
			}
	
		}	

	?>