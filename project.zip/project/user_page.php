<html>
<head>
	<link rel="stylesheet" type="text/css" href="user_page.css">
	<title>user_page</title>
</head>	
<body>

<div>
<?php include('header.php') ?>
<?php include('footer.php') ?>



<div>
	<?php
	$uid = $_GET['id'];
	$_SESSION['fid']=$uid;
	//echo $_SESSION['fid'];
	//$uid= 21;
	require("connection.php");
	$query = "SELECT * FROM regis WHERE id=$uid";
	$result = mysql_query($query);
	while($row = mysql_fetch_array($result)){
		
		echo "<div class='item'>
		<p><img src='".$row['src']."'></p>
		<p>Name: ".$row['name']."</p><p>Surname: ".$row['surname']."</p> 
		<p>Birth date:".$row['bday']."</p>
		<p>Gender: ".$row['gender']."</p>
		<p>City: ".$row['city']."</p>
		</form></div>
		</div>";
	}
	$_SESSION['friend'] = $uid;
	$myId=$_SESSION['myid'];
	$fid=$_SESSION['fid'];
	$q = "SELECT * FROM friends WHERE myid=$myId AND fid=$fid";
	$r=mysql_query($q);
	$n = mysql_num_rows($r);
	if($n == 0){echo "<a href='make_friend.php' id = 'mass'>make my friend</a>";}
	else{echo "<a href='send_mess.php' id = 'mass'>send message</a>";}
	?>
	
	<p><a href="logout.php"><button id = "logout">Log Out </button></a></p>
	

</div>
</div>


<footer>
venera.kali © SDUdent.kz
</footer>
</div>
</body>
</html>