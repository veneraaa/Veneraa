<?php
	session_start();
	include 'connection.php';
	$login = $_POST['login'];
	$password = $_POST['password']; 
    $real = "SELECT * FROM regis WHERE login='$login' AND password='$password'";
	$result = mysql_query($real);
	while($r = mysql_fetch_array($result)){
		if ($r['login'] == $login && $r['password'] == $password){
			$_SESSION["myid"] = $r['id'];
			header("Location:my_page.php?id=".$r[id]."");	
		}
		else{
			header("Location:login.php");	
		}	
	}
		
?>

